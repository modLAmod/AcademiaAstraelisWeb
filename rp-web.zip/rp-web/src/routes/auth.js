const express = require("express");
const passport = require("passport");
const router = express.Router();

router.get("/login", (req, res) => {
  if (req.isAuthenticated()) return res.redirect("/ficha");
  res.render("login", { user: null, error: req.query.error || null });
});

router.get("/auth/discord", passport.authenticate("discord"));

router.get(
  "/auth/discord/callback",
  passport.authenticate("discord", {
    failureRedirect: "/login?error=No se pudo iniciar sesión",
  }),
  (req, res) => {
    res.redirect("/ficha");
  }
);

router.post("/logout", (req, res, next) => {
  req.logout((err) => {
    if (err) return next(err);
    req.session.destroy(() => {
      res.redirect("/login");
    });
  });
});

module.exports = router;
