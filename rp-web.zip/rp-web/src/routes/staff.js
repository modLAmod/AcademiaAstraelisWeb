const express = require("express");
const db = require("../db");
const { ensureStaff } = require("../middleware/auth");
const router = express.Router();

router.get("/staff", ensureStaff, (req, res) => {
  const filtro = ["pendiente", "aprobada", "denegada"].includes(
    req.query.status
  )
    ? req.query.status
    : null;

  const fichas = filtro
    ? db
        .prepare(
          `SELECT f.*, u.username, u.avatar FROM fichas f
           JOIN users u ON u.discord_id = f.user_id
           WHERE f.status = ?
           ORDER BY f.updated_at DESC`
        )
        .all(filtro)
    : db
        .prepare(
          `SELECT f.*, u.username, u.avatar FROM fichas f
           JOIN users u ON u.discord_id = f.user_id
           ORDER BY f.updated_at DESC`
        )
        .all();

  res.render("staff", {
    user: req.user,
    fichas,
    filtro,
    ok: req.query.ok || null,
  });
});

router.post("/staff/:id/aprobar", ensureStaff, (req, res) => {
  db.prepare(
    `UPDATE fichas SET status = 'aprobada', motivo_denegacion = NULL, reviewed_by = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(req.user.username, req.params.id);
  res.redirect("/staff?ok=Ficha aprobada");
});

router.post("/staff/:id/denegar", ensureStaff, (req, res) => {
  const motivo = (req.body.motivo || "").trim() || "Sin motivo especificado";
  db.prepare(
    `UPDATE fichas SET status = 'denegada', motivo_denegacion = ?, reviewed_by = ?, updated_at = datetime('now') WHERE id = ?`
  ).run(motivo, req.user.username, req.params.id);
  res.redirect("/staff?ok=Ficha denegada");
});

router.post("/staff/:id/eliminar", ensureStaff, (req, res) => {
  db.prepare(`DELETE FROM fichas WHERE id = ?`).run(req.params.id);
  res.redirect("/staff?ok=Ficha eliminada");
});

module.exports = router;
