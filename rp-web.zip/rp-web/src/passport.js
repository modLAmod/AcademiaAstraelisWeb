const passport = require("passport");
const { Strategy: DiscordStrategy } = require("passport-discord");
const db = require("./db");

const ADMIN_IDS = (process.env.ADMIN_DISCORD_IDS || "")
  .split(",")
  .map((id) => id.trim())
  .filter(Boolean);

const scopes = ["identify"];
if (process.env.DISCORD_GUILD_ID) {
  scopes.push("guilds");
}

passport.use(
  new DiscordStrategy(
    {
      clientID: process.env.DISCORD_CLIENT_ID,
      clientSecret: process.env.DISCORD_CLIENT_SECRET,
      callbackURL: process.env.DISCORD_CALLBACK_URL,
      scope: scopes,
    },
    async (accessToken, refreshToken, profile, done) => {
      try {
        // Si se configuró un servidor obligatorio, comprobamos que el usuario esté en él
        if (process.env.DISCORD_GUILD_ID) {
          const isMember = (profile.guilds || []).some(
            (g) => g.id === process.env.DISCORD_GUILD_ID
          );
          if (!isMember) {
            return done(null, false, {
              message: "Debes estar en el servidor de Discord para entrar.",
            });
          }
        }

        const existing = db
          .prepare("SELECT * FROM users WHERE discord_id = ?")
          .get(profile.id);

        const isStaff = existing
          ? existing.is_staff
          : ADMIN_IDS.includes(profile.id)
          ? 1
          : 0;

        db.prepare(
          `INSERT INTO users (discord_id, username, discriminator, avatar, is_staff)
           VALUES (@id, @username, @discriminator, @avatar, @is_staff)
           ON CONFLICT(discord_id) DO UPDATE SET
             username = excluded.username,
             discriminator = excluded.discriminator,
             avatar = excluded.avatar`
        ).run({
          id: profile.id,
          username: profile.username,
          discriminator: profile.discriminator || "0",
          avatar: profile.avatar,
          is_staff: isStaff,
        });

        const user = db
          .prepare("SELECT * FROM users WHERE discord_id = ?")
          .get(profile.id);

        return done(null, user);
      } catch (err) {
        return done(err);
      }
    }
  )
);

// Solo guardamos el discord_id en la cookie de sesión
passport.serializeUser((user, done) => done(null, user.discord_id));

passport.deserializeUser((discord_id, done) => {
  try {
    const user = db
      .prepare("SELECT * FROM users WHERE discord_id = ?")
      .get(discord_id);
    done(null, user || false);
  } catch (err) {
    done(err);
  }
});

module.exports = passport;
