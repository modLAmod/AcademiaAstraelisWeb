const path = require("path");
const Database = require("better-sqlite3");

const dbPath = path.join(__dirname, "..", "data", "app.sqlite");
const db = new Database(dbPath);

db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    discord_id   TEXT PRIMARY KEY,
    username     TEXT NOT NULL,
    discriminator TEXT,
    avatar       TEXT,
    is_staff     INTEGER NOT NULL DEFAULT 0,
    created_at   TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS fichas (
    id                 INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id            TEXT NOT NULL UNIQUE REFERENCES users(discord_id) ON DELETE CASCADE,
    nombre_personaje   TEXT NOT NULL,
    edad               TEXT,
    raza               TEXT,
    apariencia         TEXT,
    historia           TEXT,
    habilidades        TEXT,
    imagen_url         TEXT,
    status             TEXT NOT NULL DEFAULT 'pendiente', -- pendiente | aprobada | denegada
    motivo_denegacion  TEXT,
    reviewed_by        TEXT,
    created_at         TEXT NOT NULL DEFAULT (datetime('now')),
    updated_at         TEXT NOT NULL DEFAULT (datetime('now'))
  );
`);

module.exports = db;
