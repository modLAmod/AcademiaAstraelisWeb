function ensureAuth(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated()) return next();
  return res.redirect("/login");
}

function ensureStaff(req, res, next) {
  if (req.isAuthenticated && req.isAuthenticated() && req.user.is_staff) {
    return next();
  }
  return res.status(403).render("error", {
    user: req.user || null,
    titulo: "Acceso denegado",
    mensaje: "No tienes permisos de staff para ver esta página.",
  });
}

module.exports = { ensureAuth, ensureStaff };
