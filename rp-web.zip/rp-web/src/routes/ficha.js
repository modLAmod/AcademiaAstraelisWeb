const express = require("express");
const db = require("../db");
const { ensureAuth } = require("../middleware/auth");
const router = express.Router();

function getFicha(userId) {
  return db.prepare("SELECT * FROM fichas WHERE user_id = ?").get(userId);
}

// Solo se puede escribir/editar si no existe ficha todavía, o si la que hay fue denegada
function esEditable(ficha) {
  return !ficha || ficha.status === "denegada";
}

router.get("/ficha", ensureAuth, (req, res) => {
  const ficha = getFicha(req.user.discord_id);
  res.render("ficha", {
    user: req.user,
    ficha: ficha || null,
    editable: esEditable(ficha),
    ok: req.query.ok || null,
    error: req.query.error || null,
  });
});

router.post("/ficha", ensureAuth, (req, res) => {
  const ficha = getFicha(req.user.discord_id);

  if (!esEditable(ficha)) {
    return res.redirect(
      "/ficha?error=Tu ficha ya está en revisión o aprobada, no se puede editar"
    );
  }

  const {
    nombre_personaje,
    edad,
    raza,
    apariencia,
    historia,
    habilidades,
    imagen_url,
  } = req.body;

  if (!nombre_personaje || !nombre_personaje.trim()) {
    return res.redirect("/ficha?error=El nombre del personaje es obligatorio");
  }

  db.prepare(
    `INSERT INTO fichas (user_id, nombre_personaje, edad, raza, apariencia, historia, habilidades, imagen_url, status, motivo_denegacion, reviewed_by, updated_at)
     VALUES (@user_id, @nombre_personaje, @edad, @raza, @apariencia, @historia, @habilidades, @imagen_url, 'pendiente', NULL, NULL, datetime('now'))
     ON CONFLICT(user_id) DO UPDATE SET
       nombre_personaje = excluded.nombre_personaje,
       edad = excluded.edad,
       raza = excluded.raza,
       apariencia = excluded.apariencia,
       historia = excluded.historia,
       habilidades = excluded.habilidades,
       imagen_url = excluded.imagen_url,
       status = 'pendiente',
       motivo_denegacion = NULL,
       reviewed_by = NULL,
       updated_at = datetime('now')`
  ).run({
    user_id: req.user.discord_id,
    nombre_personaje: nombre_personaje.trim(),
    edad: edad || null,
    raza: raza || null,
    apariencia: apariencia || null,
    historia: historia || null,
    habilidades: habilidades || null,
    imagen_url: imagen_url || null,
  });

  res.redirect("/ficha?ok=Ficha enviada, queda pendiente de revisión");
});

module.exports = router;
